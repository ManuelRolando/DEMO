/*
 * Register.h
 *
 *  Created on: Jul 4, 2020
 *      Author: solalu
 */

#ifndef INCLUDE_REGISTER_H_
#define INCLUDE_REGISTER_H_

#include "Player.h"
#include "Answer.h"

#include <vector>

class Register
{
protected:
	std::vector<Player> * register_players;


};



#endif /* INCLUDE_REGISTER_H_ */
