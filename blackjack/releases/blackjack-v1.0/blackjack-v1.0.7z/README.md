# BlackJack Game - C++

## NOTE - Windows Users
You should install the [MinGW](http://mingw.org/) compiler for compile this game. For this propose watch [Installation of MinGW in Windows](https://www.youtube.com/watch?v=hAnTiNm7mUE) and then follow the next explication.

## Compilation
The main function is in `blackjack.cpp` file(within src directory). You should compile it with the next command(**Run this Within src directory**):

```bash
g++ blackjack.cpp ../src/Player.cpp ../src/Answer.cpp ../src/Hand.cpp ../src/Deck.cpp ../src/Card.cpp ../src/Group.cpp -o blackjack
``` 

So you should get the `blackjack`executable file.
Finaly, you should run `blackjack`.

ENJOY PLAYING IT!


