#include "../include/Card.h"
#include<iostream>

using namespace std;

int main()
{
    /*
    SuitCard king;
    king.suit = "Hearts";
    king.symbol = "♥";

    cout << "king card:"
        << "\nSuit: " << king.suit
        << "Symbol: " << king.symbol << endl;
    */

   /* // NOTE SOME ERROR (BECAUSE I CONVERT Card struct to Card Class)
   Card queen;
   queen.value = 12;
   queen.suitCard.suit = "Hearts";
   queen.suitCard.symbol = "♥";

   cout << "Queen Card:" 
        << "\n Value: " << queen.value
        << "\n Suit: " << queen.suitCard.suit
        << "\n Symbol: " << queen.suitCard.symbol << endl;
    */
}