#include<iostream>
#include<string>

using namespace std;

#define welcome = R"(
 _     _            _     _            _
| |__ | | __ _  ___| | __(_) __ _  ___| | __
| '_ \| |/ _` |/ __| |/ /| |/ _` |/ __| |/ /
| |_) | | (_| | (__|   < | | (_| | (__|   <
|_.__/|_|\__,_|\___|_|\_\/ |\__,_|\___|_|\_\
                       |__/
)";

int main()
{


	cout << welcome << endl;

	return 0;

}
