/*

 * clear_terminal.cpp
 *
 *  Created on: Jul 3, 2020
 *      Author: glozanoa
 */


#include <iostream>
using namespace std;

int main()
{
	for(int i=0; i<15; i++)
		cout << "index: " << i << endl;

	system("clear");

	return 0;
}

