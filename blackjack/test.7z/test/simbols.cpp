#include<iostream>

int main()
{
    std::cout << "corazones: ♥" << std::endl;
}